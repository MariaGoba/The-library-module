<?php
header('Content-Type: text/html; charset=utf-8');

$dir = opendir("./");
$plugins = array();
while($any_file = readdir($dir)) {
    if (is_file($any_file)) {
        if (strpos($any_file, '.plugin.php') !== false) {
            include("./".$any_file);
            $plugins[] = substr($any_file, 0, strpos($any_file, '.plugin.php'));
        }
    }
}
closedir($dir);

$text = file_get_contents("input.txt");

print "<p>Text:</p><p>";
print_r($text);
print "</p>";

foreach($plugins as $p) {
    $switch = $p.'_switch';
    if (!function_exists($switch)) {
        print "<p>Plugin $p contains error.</p>";
    } else {
        print "<p>Text after $p plugin work:</p><p>";
        print call_user_func($switch, $text);
        print "</p>";
    }
}
?>


