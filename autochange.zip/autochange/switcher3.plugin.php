<?php

function switcher3_switch($text) {
    $text = mb_ereg_replace("[ё]", "е", $text);
    $text = mb_ereg_replace("[Ё]", "е", $text);
    return $text;
}