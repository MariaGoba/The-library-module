<?php

function switcher2_switch($text) {
    $text = mb_ereg_replace("[е]", "и", $text);
    $text = mb_ereg_replace("[Е]", "И", $text);
    return $text;
}