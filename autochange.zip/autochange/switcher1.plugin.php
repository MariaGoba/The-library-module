<?php

function switcher1_switch($text) {
    $text = mb_ereg_replace("[о]", "а", $text);
    $text = mb_ereg_replace("[О]", "А", $text);
    return $text;
}