<?php

class Administrator //интерфейс администратора, позволяющий добавлять, изменять и удалять записи о книгах
{
    public function getForm($request) //вывод формы (карточка книги) польователю, которую ему нужно зполнить
    {
        $route = $request["route"];
        include('views/form.php'); //view (представление) для формы
        die;
    }

    public function addNewBook ($request) //добавить книгу
    {
        $db = DB::getInstance();
        $db = $db->getConnection();
        $book = $request['book'];
        $query = $db->prepare('INSERT INTO `books` (`name`, `author`, `year`, `annotation`, `theme`, `used`, `photo`) VALUES (?, ?, ?, ?, ?, NULL, ?)'); //запрос к бд
        $query->execute([$book['name'], $book['author'], $book['year'], $book['annotation'], $book['theme'], $book['photo']]);
        print "<p>Book added.</p>";
    }

    public function changeBookInfo ($request) //изменить существующую книгу
    {
        $db = DB::getInstance();
        $db = $db->getConnection();
        $book = $request["book"];
        $id = $request["id"];
        $query = $db->prepare('UPDATE `books` SET `name` = ?, `author` = ?, `year` = ?, `annotation` = ?, `theme` = ?, `used` = ?, `photo` = ? WHERE `id` = ?'); //запрос к бд
        $query->execute([$book['name'], $book['author'], $book['year'], $book['annotation'], $book['theme'], $book['used'], $book['photo'], $id]);
        print "<p>Book changed.</p>";
    }

    public function deleteBook ($request) //удалить книгу
    {
        $db = DB::getInstance();
        $db = $db->getConnection();
        $id = $request["id"];
        $query = $db->prepare('DELETE FROM `books` WHERE `id` = ?'); //запрос к бд
        $query->execute([$id]);
        print "<p>Book deleted.</p>";
    }
}