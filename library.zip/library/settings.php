<?php
namespace Settings;
//файл с настройками для подключения базы данных
$settings = [
    'host' => '127.0.0.1',
    'port' => '3306',
    'name' => 'oookorzr_library',
    'username' => 'oookorzr_library',
    'password' => 'cP3&ln65',
    'charset' => 'utf8'
];