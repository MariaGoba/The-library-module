<?php

class DB
{
    private static $_instance = null; //The single instance - единственная сущность
    private $_connection;

    private function __construct () {
        include('settings.php');
        try {
            $this->_connection = new PDO( //подключаем базу данных
                sprintf(
                    'mysql:host=%s;dbname=%s;port=%s;charset=%s',
                    $settings['host'],
                    $settings['name'],
                    $settings['port'],
                    $settings['charset']
                ),
                $settings['username'],
                $settings['password']
            );
        } catch (PDOException $e) { //ловим исключение, если произошла ошибка при подключении
            //db connection error
            echo "Database connection failed";
            exit;
        }
    }

    private function __clone () {}
    private function __wakeup () {}

    public static function getInstance()
    {
        if (self::$_instance != null) {
            return self::$_instance;
        }

        return new self; //если $_instance не NUll, т е один раз было настроено подключение, то возращаем $_instance, потому что подключение должно быть единственным
    }

    public function getConnection() {
        return $this->_connection; //получаем соединение
    }
}