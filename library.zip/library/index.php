<?php

include('database.php'); //покдлючаем другие нужные файлы
include('book.php');
include('administrator.php');

require 'vendor/autoload.php';

$dispatcher = FastRoute\simpleDispatcher(function(FastRoute\RouteCollector $r) {
    $r->addRoute('GET', '/library/books/{page:\d+}', 'Book/getAllBooks');
    $r->addRoute('GET', '/library/books/{sort}/{page:\d+}', 'Book/getAllBooksSorted');
    $r->addRoute('GET', '/library/availableBooks/{page:\d+}', 'Book/getAvailableBooks');
    $r->addRoute('GET', '/library/book/{id:\d+}', 'Book/getBookInfo');
    $r->addRoute('GET', '/library/addNewBook', 'Administrator/getForm');
    $r->addRoute('POST', '/library/addNewBook', 'Administrator/addNewBook');
    $r->addRoute('GET', '/library/changeBook/{id:\d+}', 'Administrator/getForm');
    $r->addRoute('POST', '/library/changeBook/{id:\d+}', 'Administrator/changeBookInfo');
    $r->addRoute('GET', '/library/deleteBook/{id:\d+}', 'Administrator/getForm');
    $r->addRoute('POST', '/library/deleteBook/{id:\d+}', 'Administrator/deleteBook');
});

$httpMethod = $_SERVER['REQUEST_METHOD'];
$uri = $_SERVER['REQUEST_URI'];

if (false !== $pos = strpos($uri, '?')) {
    $uri = substr($uri, 0, $pos);
}
$uri = rawurldecode($uri);

$routeInfo = $dispatcher->dispatch($httpMethod, $uri);
switch ($routeInfo[0]) {
    case FastRoute\Dispatcher::NOT_FOUND:
        // ... 404 Not Found такого пути нет
        break;
    case FastRoute\Dispatcher::METHOD_NOT_ALLOWED:
        $allowedMethods = $routeInfo[1];
        // ... 405 Method Not Allowed такой путь не разрешен
        break;
    case FastRoute\Dispatcher::FOUND: //путь найден и разрешен
        $handler = $routeInfo[1];
        switch ($httpMethod) {
            case 'POST':
                $vars = array_merge($routeInfo[2], $_POST);
                break;
            default: $vars = $routeInfo[2];
        }
        $vars["route"] = $uri; //переменные, с которыми будут вызываться методы

        list($class, $method) = explode("/", $handler, 2); //$class - класс, $method - метод, те что пришли их хендлера
        call_user_func_array(array(new $class, $method), array($vars)); //вызываем нужный метод нужного класса с нужными переменными

        break;
}




