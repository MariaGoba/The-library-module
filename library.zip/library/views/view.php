<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF8">
</head>
<body>
<?php
foreach ($books as $book){
    include('book-view.php');
}
?>
</body>