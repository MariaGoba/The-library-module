<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF8">
</head>
<body>
    <form action="<?=$route;?>" method="post">
        <p>Название книги: <input type="text" name="book[name]" /></p>
        <p>Автор: <input type="text" name="book[author]" /></p>
        <p>Год издания: <input type="text" name="book[year]" /></p>
        <p>Аннотация: <input type="text" name="book[annotation]" /></p>
        <p>Тематика: <input type="text" name="book[theme]" /></p>
        <p>Выдана(NULL - нет, 0 - да): <input type="text" name="book[used]" /></p>
        <p>Фотография обложки: <input type="text" name="book[photo]" /></p>
        <p><input type="submit" /></p>
    </form>
</body>