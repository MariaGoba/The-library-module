<?php

//класс Книга

class Book
{
    CONST num = 10;

    public function getAllBooks($request) //вывод списка всех книг библиотеки
    {
        $page = $request["page"];
        $db = DB::getInstance();
        $db = $db->getConnection();
        $bottom  = $page*self::num - self::num;
        $top = self::num; //боттом и топ, для того чтобы выдавать только книги на конкретной станице
        $books = $db->prepare('SELECT * FROM books LIMIT :bottom, :top'); //запрос к бд
        $books->bindParam(':bottom', $bottom, PDO::PARAM_INT);
        $books->bindParam(':top', $top, PDO::PARAM_INT);
        $books->execute();
        return include('views/view.php'); //полученный массив $books представляем пользователю с помощью view
    }

    public function getAllBooksSorted($request) { //вывод списка всех книг библиотеки отсортированных по параметру
        $sort = $request["sort"];
        $page = $request["page"]; //параметр по которому сортируем
        $db = DB::getInstance();
        $db = $db->getConnection();
        $bottom  = $page*self::num - self::num;
        $top = self::num; //боттом и топ, для того чтобы выдавать только книги на конкретной станице
        $books = $db->prepare('SELECT * FROM books ORDER BY '.$sort.' LIMIT :bottom, :top'); //запрос к бд
        $books->bindParam(':bottom', $bottom, PDO::PARAM_INT);
        $books->bindParam(':top', $top, PDO::PARAM_INT);
        $books->execute();
        return include('views/view.php'); //полученный массив $books представляем пользователю с помощью view
    }

    public function getAvailableBooks($request) //вывод cписка доступных (не выданных) книг (used == 0)
    {
        $page = $request["page"];
        $db = DB::getInstance();
        $db = $db->getConnection();
        $bottom  = $page*self::num - self::num;
        $top = self::num;
        $books = $db->prepare('SELECT * FROM books WHERE used = 0 LIMIT :bottom, :top'); //запрос к бд
        $books->bindParam(':bottom', $bottom, PDO::PARAM_INT);
        $books->bindParam(':top', $top, PDO::PARAM_INT);
        $books->execute();
        return include('views/view.php');
    }

    public function getBookInfo ($request) { //вывод карточки книги
        $id = $request["id"];
        $db = DB::getInstance();
        $db = $db->getConnection();
        $book = $db->prepare('SELECT * FROM books WHERE id = ?'); //запрос к бд
        $book->execute([$id]);
        $books = array($book->fetch(PDO::FETCH_ASSOC));
        return include('views/view.php');
    }
}